This folder contains documentation for the FF three-phase motor controller hardware.
Software will be handled in a different set of documentation.

Hardware Version: 1.2s

Contents:
FF_v1_2s_BOM.xlsx	Bill Of Materials
FF_v1_2s_BOT.png	bottom layer assembly diagram (with part designators)
FF_v1_2s_CAM.zip	board Gerber files for PCB printing
FF_v1_2s_EAG.zip	EAGLE schematic, board, and library files
FF_v1_2s_REF.zip	component datasheets
FF_v1_2s_SCH.png	static schematic (see EAGLE files for editable schematic)
FF_v1_2s_TOP.png	top layer assembly diagram (with part designators)

Board specs will depend on the MOSFETs and bus capacitors chosen, as well as air flow and heat sinking. Maximum voltage is 50V, regardless of MOSFET voltage rating. Continuous current of 15A and 10-second peak current of 30A are possible. Suggested MOSFETS:

BSC016N04LS G	(40V, 1.6mOhm, 113nC)
BSC010N04LS	(40V, 1.0mOhm, 95nC)
BSC014N06NS	(60V, 1.45mOhm, 89nC)




