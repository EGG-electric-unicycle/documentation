This folder contains documentation for the FF three-phase motor controller hardware.
Software will be handled in a different set of documentation.

Hardware Version: 1.1

Contents:
FF_v1_1_BOM.xlsx	Bill Of Materials
FF_v1_1_BOT.png		bottom layer assembly diagram (with part designators)
FF_v1_1_CAM.zip		board Gerber files for PCB printing
FF_v1_1_EAG.zip		EAGLE schematic, board, and library files
FF_v1_1_REF.zip		component datasheets
FF_v1_1_SCH.png		static schematic (see EAGLE files for editable schematic)
FF_v1_1_TOP.png		top layer assembly diagram (with part designators)

Board specs will depend on the MOSFETs and bus capacitors chosen, as well as air flow and heat sinking. Maximum voltage is 50V, regardless of MOSFET voltage rating. Continuous current of 30A and 10-second peak current of 75A are possible. Suggested MOSFETS:

IRFS3004-7PPbF	(40V, 0.9mOhm, 160nC)
IPB017N06N3 G 	(60V, 1.7mOhm, 206nC)
IPB010N06N	(60V, 1.0mOhm, 208nC)
IRFS3107-7PPbF	(75V, 2.1mOhm, 160nC)


